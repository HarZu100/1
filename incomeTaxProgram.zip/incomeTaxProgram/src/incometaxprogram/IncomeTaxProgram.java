/*
 * Haris Zuair
 * Febuary 9 2022
 * IncomeTaxProgram.java 
 * This program calculates your income tax depending on your income
 */
package incometaxprogram;

import java.util.Scanner;

public class IncomeTaxProgram {

    
    public static void main(String[] args) {
        
        Scanner keyedInput = new Scanner(System.in); 
        
        //Constants and variables stated 
        final double TAX_RATE = 5.05;
        double income;
        double incomeTax; 
        
        //What user will see
        System.out.println("What is you salary? State here:");
        income = keyedInput.nextDouble(); 
        
        //Calculations
        incomeTax = (income / 100)* TAX_RATE + income; 
        
        //What user will see 
        System.out.println("The income tax you owe is:"+incomeTax);
    }
    
}
